import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException{
        try(BufferedReader br = new BufferedReader(new FileReader("Colombo.txt"))){
            String num;
            String englishName;
            String nativeName;
            String readLine = br.readLine();
            while (readLine != null){
                num = readLine.split(",")[0];
                englishName = readLine.split(",")[1];
                nativeName = readLine.split(",")[2];

                System.out.println("Colombo " + num + " - " + englishName + " - " + nativeName );
                readLine = br.readLine();
            }
        }
    }
}
